ALTER TABLE `user` ADD `image` text(255);--> statement-breakpoint
ALTER TABLE `user` ADD `name` text(100);--> statement-breakpoint
ALTER TABLE `user` ADD `lastname` text(100);